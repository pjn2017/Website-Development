var index = 0;
document.write ("<table><table border = '4'>");
document.write ("<caption> % of Savings </caption>");
document.write ("<tr> <th># of Devices</th>" ,
"<th>In-Shop $75 per hour</th>",
"<th>On-site $85 per hour(within 15 mile radius)</th>",
"<th>Pick Up & Drop-off $35 per hour(within 15 mile radius) </th>",
"</tr>");
for (index = 1;index < 11; index++)
{
	document.write ("<tr>",
	"<th>" +  index +  "</th>",
	"<th>" +  (index * .03) + "</th>",
	"<th>" +  (index * .02) + "</th>",
	"<th>" +  (index * .01) + "</th>",
	"</tr>");
}
document.write ("</table>");