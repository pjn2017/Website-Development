</head>
  <body>
    
<form action="items2.php" method="post">
	
	<h1> LAPTOP PCs FOR SALE!!!</h1>

	
	

	
	
	
	
	
	
	<p> <label>
	Your Name: <br>    
	<input type= "text" name = "name" id = "custName" size = "25"  /> 
       <br> </label>
	<label> Your Age: <br>     
	<input type= "text"name = "age" id = "age"  /> 
	 <br> </label>
	 </p>
   
   <p>
   <label>
   Search for your item:
	<input type = "text"  name = "itemID" size = "30"   onblur = "getLaptop(this.value)"  /> 
	<br> </label>
	 </p>
	
	
	<p>
	<input type = "text" name = "describe" id = "describe" size = "70"  /> 
  <br> 
  </p>
  
  
  <p>
 <input type="submit"  id ="mySubmit"   value="Order"   />
<input type = "reset"  " value = "Clear Order Form"   /> 
</p>



<a href="index.php"> HOME </a>

</form>
  
  </body>
</html>