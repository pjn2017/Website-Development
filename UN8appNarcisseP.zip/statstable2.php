<?xml version="1.0" encoding="utf-8"?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

 <html lang = "en"  xmlns="http://www.w3.org/1999/xhtml">

  <!-- PHP Table
     Example of php
     -->

  <head> 
    <title> Rates Chart </title>
    
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  <style type = "text/css">
	
    td, th {border: thin solid black;}
    table {border: thin solid black;
           border-collapse: collapse;
           border-top-width: thin solid black;
           border-bottom-width: thin solid black;
           border-top-color: thin solid black;
           border-bottom-color: thin solid black;
           border-top-style: thin solid black;
           border-bottom-style: thin solid black; 
          }
   
   
    </style>
  
  </head>
  <body>
     <h1> The More Devices You Have, The More You Save!!!</h1> 
	

	   
	   <p>

	   

	   
In-Shop Computer Service: 
</p>


<p>
When you drop off your computer, We GUARANTEE results in three days!!!. 
</p>

<p>
On-Site Computer Service: 
</p>

<p>
On-site service is only available within 15 miles of our store location.
</p>

<p>
Pick-Up and Drop-off: 
</p>

<p>
Requires an appointment at least one day in advance. Requires someone 18 years or older to be present.
 
</p>

<p>
Payment:
</p>

<p>
Payment is due on date of service or when picking up and is payable to PJN PC Repair.
</p>

<p>
⦁	Credit Card/Debit Card (Visa, Mastercard, Amex, Discover) 
⦁	Check 
⦁	Cash
</p>

<p>
Our Guarantee:
</p>


<p>
Hardware repairs come with a 30 day labor warranty. 
If your computer breaks down with the same problem
 within 30 days of the repair, we will fix it free 
 of any labor charge. Any warranty work or repairs
 must be diagnosed and performed by PJN PC Repair 
 or the warranty is void. No warranty for virus/adware 
 infections, operating system crashes, or software. Parts
 used for repairs, or any equipment sold to you are 
 subject to the manufacturer’s warranty only. 
</p>

 

 <table border = '4'>
<caption> % of Savings </caption>
<tr> 
<th># of Devices</th>
<th>In-Shop $75 per hour</th>
<th>On-site $85 per hour(within 15 mile radius)</th>
<th>Pick Up and Drop-off $35 per hour(within 15 mile radius) </th>
</tr>

<?php

for ($number = 1; $number <=15; $number++){
	$shop = $number * .03;
	$site = $number * .02;
	$drop = $number * .01;
	
	print("<tr><th>$number</th><th>$shop</th><th>$site</th><th>$drop</th></tr>");
}


?>
  </table>
 
        
 
  <p>
    <a href="index.php"> HOME </a>
</p>
  
  </body>


  
  </html>
