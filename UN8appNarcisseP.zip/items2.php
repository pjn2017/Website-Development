<?xml version="1.0" encoding="utf-8"?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
 
<!-- items2.php - Processes the form
     -->
<html xmlns = "http://www.w3.org/1999/xhtml">
  <head>
    <title> Process the items.php form </title>
  </head>
  <body>
    
 <!-- items2.php - Processes the form described in
     items.php
     -->

 <html lang = "en"  xmlns = "http://www.w3.org/1999/xhtml">
   <head>
    <title>Laptop Sales for PHP Handling</title>
   </head>

 <body>

 <h1>Your Order</h1>

<?php

 $itemID = $_POST["itemID"];
 $describe = $_POST["describe"];
 $name = $_POST["name"];
 $age = $_POST ["age"];  



	  
	  
echo ("<p>" . date("l F jS Y") . "</p>");
echo ("<p>Thank you for your order " . $name . ".". "</p>") ;
echo ("<p>Your age is " . $age. " so we can sell you ".$itemID. " laptop today.". "</p>") ;



// -----------------FILE OUTPUT ---------------------------
	// used in file output;
	$today = date("l, F jS Y");

	// Create a variable for the file
	$myFile = "laptopsales.dat";
	// Open file for Append
	$file_var = fopen($myFile, "a+");

	// write all data to file 
	// output date, name, age, and item number
	$output = "$today  $name  $age  \n";
	fwrite($file_var,$output);

	// make sure you close the file.
	fclose($file_var);

?>
<h1> Order Information</h1>
<?php
print("$name<br/>$age<br/>");
?>

   
<p>
       <a href = "items3.php"> Would you like to purchase another laptop? </a> 
	   </p>
 </body>
 </html>
