<!DOCTYPE html>
<html lang = "en">

  <!-- Antivirus.php
       Compares top rated antivirus software
       -->
	   
	   
		  
		 
		  <head> 
      <title> Calculate Spyware </title>
      
	  <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
	  
	  
    
	
	</head>
    <body>
      
	  <h1> How much Spyware Do You Have!!! </h1>
	
        <p>
       <script type = "text/javascript">

	   var number1, number2, number3, sum;
	
 number1 = Number(prompt("How much  Adware was on your computer? \n", ""));
 number2 = Number(prompt("How much  Cookies were on your computer? \n", ""));  
 number3 = Number(prompt("How much  Malware was on your computer? \n", ""));     
	   sum = number1 + number2 + number3;
	   product = number1 * number2 * number3;
	   
	   alert("The sum is: " + sum + "\n");
	   alert("The product is: " + product + "\n");
       
	   </script> 
      </p>
    
	<a href="index.php"> HOME </a>
	
	</body>
  </html>
  
  