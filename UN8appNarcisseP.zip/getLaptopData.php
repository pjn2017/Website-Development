<?php
// getLaptopData.php 

      
  $laptopData = array("acer" => "The Aspire One Cloudbook is an online-oriented laptop ",
                     "lenovo" => "The Lenovo N22 notebook family was built with the specific needs of students in mind.",
                     "asus" => "The ASUS EeeBook X205 is an affordable 11.6-inch notebook.",
                     "dell" => "Enjoy a hassle-free experience with the affordable Dell Chromebook 11.",
                     );
  $itemID = $_GET["itemID"];
  if (array_key_exists($itemID, $laptopData))
    print $laptopData[$itemID];
  else
 print "We don't carry this item.";



?>




