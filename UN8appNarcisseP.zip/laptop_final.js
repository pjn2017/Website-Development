function getLaptop(itemID) {
  if (window.XMLHttpRequest)
  
  xhr = new XMLHttpRequest();

  else
	  
  xhr = new ActiveXObject("Microsoft.XMLHTTP");
  
  
// Register the embedded handler function
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
      var result = xhr.responseText;
      var place = result.split(', ');
     
	  if (document.getElementById("describe").value == "")
        document.getElementById("describe").value = place[0];
     
	 
    

	}
  
 

  
  }
  
  xhr.open("GET", "getLaptopData.php?itemID=" + itemID);
  xhr.send(null);

 
  }

 

