<!DOCTYPE html>
<!-- Evilgame.php
     An example to try and click a tech.
     -->
<html lang = "en">



  <head> 
    <title> Evil Image </title>
    
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  <script type = "text/javascript"  src = "evilgame.js" >
    </script>
  </head>
  <body>
  <h1> Try To Click A Tech!!! </h1>
  
  
 
 
 
 
<p> Catch him if you can !!!</p> <br />
<div id = "amps" style = "position: relative; visibility: visible;" onmousedown = "moveImage()">
<img src = "tech.jpg" alt = "amp" />

</div>

  <a href="index.php"> YOU CAN'T GO HOME! </a>
 </body>
</html>