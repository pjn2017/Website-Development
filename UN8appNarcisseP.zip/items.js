// items.js
// Code to validate user input.

function validateForm()
{
// Validates name.
	if (document.myForm.name.value == "")
	{
		alert ("Please enter your name!");
		return false;
	} 
	
	// Validates age.
	if (isNaN(document.myForm.age.value))
	{
		alert ("Please enter your age!");
		return false;
	} 
// Validates age between 18 & 110.
	
	var newage = parseInt(document.myForm.age.value) * 1;
	if ((newage < 18) || (newage > 110) )
	{
		alert ("In order to buy an item you have to be 18 or older!");
		return false;
	} 
	

	var retval = false;
	for (var i=0; i < document.myForm.Laptop.length; i++)
	{
		if (document.myForm.Laptop[i].checked == true)
		{
		  retval = true;
		}
	}
	
	// Informs user to select a laptop.
	if (retval == false)
	{	
		alert(" Please select which laptop you wish to purchase, " + myForm.name.value);
	}
	return retval; 
}