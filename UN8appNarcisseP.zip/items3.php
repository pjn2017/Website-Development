
<!DOCTYPE html>
<html lang = "en">

  <!-- Items.php
       Laptops for sale
       -->
 
  <!-- Start the session in the first page that opens -->


<!-- items2.php 
     Uses session variables.
     -->
  
  
 
  
  <head> 
    <title> Items for sale</title>
	
	<script type = "text/JavaScript" src = "laptop_final.js">
     </script>
	
	
    <meta charset = "utf-8" />
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  <style type = "text/css">
    td, th {border: thin solid black;}
    table {border: thin solid black;
           border-collapse: collapse;
           border-top-width: medium;
           border-bottom-width: thick;
           border-top-color: blue;
           border-bottom-color: blue;
           border-top-style: dashed;
           border-bottom-style: solid; 
          }
   
    p.one   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
	p.two   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
			  
    p.three   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
   p.four   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
</style>
  
  </head>
  <body>
    
<form action="items2.php" method="post">
	
	<h1> LAPTOP PCs FOR SALE!!!</h1>

	
	

	
	
	
	
	
	
	<p> <label>
	Your Name: <br>    
	<input type= "text" name = "name" id = "custName" size = "25"  /> 
       <br> </label>
	<label> Your Age: <br>     
	<input type= "text"name = "age" id = "age"  /> 
	 <br> </label>
	 </p>
   
   <p>
   <label>
   Search for your item:
	<input type = "text"  name = "itemID" size = "30"   onblur = "getLaptop(this.value)"  /> 
	<br> </label>
	 </p>
	
	
	<p>
	<input type = "text" name = "describe" id = "describe" size = "70"  /> 
  <br> 
  </p>
  
  
  <p>
 <input type="submit"     value="Order"   />
<input type = "reset"  " value = "Clear Order Form"   /> 
</p>



<a href="index.php"> HOME </a>

</form>
  
  </body>
</html>