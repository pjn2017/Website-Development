// evilgame.js
// Play the keep away game. 
function flipImag() {
dom = document.getElementById("amps").style;

// Flip the visibility adjective to whatever it is not now
if (dom.visibility == "visible")
dom.visibility = "hidden";
else
dom.visibility = "visible";
} // end Function flipImag

function moveImage() {
var x = 10;  // starting Location - left
var y = 20; //Starting Location - top
dom = document.getElementById("amps").style;
if (dom.visibility == "visible")
dom.visibility = "hidden";

//Keep on moving the image till the target is achieved
x = randomFromTo(8,200);
y = randomFromTo(8,200);

//Move the image to the new location
document.getElementById("amps").style.top = y+'px';
document.getElementById("amps").style.left = x+'px';
Func_Delay();
} // end Function moveImage

function randomFromTo(from, to){
return Math.floor(Math.random() * (to - from + 1) + from);
} // end Function randomFromTo

function Func_Delay()
{
setTimeout("flipImag()", 1000);
} // end Function Func_Delay