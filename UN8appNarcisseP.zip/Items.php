<!DOCTYPE html>
<html lang = "en">

  <!-- Items.php
       Laptops for sale
       -->
 
  <!-- Start the session in the first page that opens -->
<?php session_start(); 
if(isset($_SESSION['views']))
$_SESSION['views']=$_SESSION['views']+1;
else
$_SESSION['views']=1;
echo "Views = ". $_SESSION['views'];
if(isset($_SESSION['posted'])) {
	
	//echo "Views=". $_SESSION['posted'];
	
	$name = $_SESSION["name"];
	$age = $_SESSION["age"];
	

	// this variable was added to hide text fields
	$InputType = "hidden";
} else {
	$name = "";
	$age = "";
	

	// this variable was added to hide text fields
	$InputType = "text";
}
?>

<!-- items2.php 
     Uses session variables.
     -->
  
  
 
  
  <head> 
    <title> Items for sale</title>
	<script type = "text/javascript" src = "items.js" > </script>
	
    <meta charset = "utf-8" />
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  <style type = "text/css">
    td, th {border: thin solid black;}
    table {border: thin solid black;
           border-collapse: collapse;
           border-top-width: medium;
           border-bottom-width: thick;
           border-top-color: blue;
           border-bottom-color: blue;
           border-top-style: dashed;
           border-bottom-style: solid; 
          }
   
    p.one   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
	p.two   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
			  
    p.three   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
   p.four   {margin: 15px;
               padding: 15px;
               font-style: italic;
              }
			  
</style>
  
  </head>
  <body>
    
<form action="items2.php" name="myForm" onSubmit="returnvalidateForm();"method="post">
	
	<h1> LAPTOP PCs FOR SALE!!!</h1>

	<table>

<caption> Lowest Prices Guaranteed!!! </caption>
      
	  <tr>
        
       <td> </td>
	   <th> Select </th>
		<th> Name </th>
        <th> Picture </th>
        <th> Description </th>
		<th> Unit Price </th>
		
		
      </tr>
      
	  <tr>
        <th> </th>
        
		<td>
		
		
		<fieldset>
  <legend> <br /> Buy <br />
						It <br /> Now</legend>

		<label> <input type = "radio"  name = "Laptop"  
                       value = "1" id = "Acer"
                        /> Free <br /> Shipping</label>
						
						</fieldset>

		</td>
		<td> Acer Aspire One Cloudbook 11 AO1-131M-C667 - 11.6"</td>
        <td> <img src = "pc1.jpg"  alt = "PC pic" />  </td>
        <td> 
	
	<p class = "one">	
		
The Aspire One Cloudbook is an online-oriented laptop that 
gets you into the cloud faster. A big bang in a small box, 
it's a highly portable device that keeps you productive with a 
super-fast wireless connection and a host of other features.
Specifications
General
   Product Type:  Notebook
   Operating System:  Windows 10 Pro 32-bit Edition

Processor / Chipset
   CPU:  Intel Celeron N3050 / 1.6 GHz
   Max Turbo Speed:  2.16 GHz
   Number of Cores:  Dual-Core
   Cache:  L2 - 2 MB
   64-bit Computing:  Yes
   Features:  Intel Burst Technology

Memory
   RAM:  2 GB ( 1 x 2 GB )
   Technology:  DDR3L SDRAM
   Speed:  1600 MHz
   Form Factor:  SO-DIMM 204-pin

Storage
   Main Storage:  16 GB SSD
   SSD Form Factor:  eMMC

Display
   Type:  11.6"
   LCD Backlight Technology:  LED backlight
   Resolution:  1366 x 768 ( HD )
   Widescreen:  Yes
   Image Brightness:  220 cd/m2
   Features:  HDCP, anti-glare, ComfyView

Audio & Video
   Graphics Processor:  Intel HD Graphics
   Memory Allocation Technology:  Shared video memory (UMA)
   Camera:  Integrated webcam
   Resolution (MP):  0.3 Megapixel
   Resolution:  640 x 480
   Sound:  Stereo speakers , two microphones
   Compliant Standards:  High Definition Audio

Input
   Type:  Keyboard, touchpad

Communications
   Wireless:  Bluetooth 4.0, 802.11ac
   Wireless Controller:  Intel Dual Band Wireless-AC 3160

Battery
   Technology:  2-cell lithium polymer
   Capacity:  4350 mAh

AC Adapter
   Input:  AC 120/230 V ( 50/60 Hz )
   Output:  45 Watt , 19 V

Connections & Expansion
   Interfaces:  HDMI ¦ USB 2.0 ¦ USB 3.0 ¦ Headphone output
   Memory Card Reader:  Yes ( SD Card )

Miscellaneous
   Color:  Gray
   Included Accessories:  Power adapter
   Localization:  United States

Dimensions & Weight
   Dimensions (WxDxH):  11.5 in x 8 in x 0.7 in
   Weight:  2.54 lbs
</p>
 </td>
      <td> $480.00 </td>
	  
	  </tr>
      <tr>
        <th>  </th>
        <td>
		<fieldset>
  <legend> <br /> Buy <br />
						It <br /> Now</legend>

		<label> <input type = "radio"  name = "Laptop"  
                       value = "2" id = "Lenovo"
                        /> Free <br /> Shipping</label>
						
						</fieldset>
		</td>

		<td> Lenovo N22 Chromebook 80SF - 11.6" - Celeron N3050 </td>
        <td> <img src = "pc2.jpg"  alt = "PC2 pic" /> </td>
        <td> 
		
		<p class = "two">	
		The Lenovo N22 notebook family was built with the specific needs of students in mind. 
		Models feature an 11.6-inch HD display, Wi-Fi and are powered by an Intel dual-core Celeron processor. 
		A large battery provides all-day charge for greater productivity.
		

Specifications
General
   Product Type:  Chromebook
   Operating System:  Google Chrome OS

Processor / Chipset
   CPU:  Intel Celeron N3050 / 1.6 GHz
   Max Turbo Speed:  2.16 GHz
   Number of Cores:  Dual-Core
   Cache:  2 MB
   64-bit Computing:  Yes
   Features:  Integrated memory controller

Memory
   RAM:  2 GB ( provided memory is soldered )
   Max RAM Supported:  8 GB
   Technology:  DDR3L SDRAM
   Speed:  1600 MHz

Storage
   Main Storage:  16 GB SSD
   SSD Form Factor:  eMMC

Display
   Type:  11.6"
   LCD Backlight Technology:  LED backlight
   Resolution:  1366 x 768 ( HD )
   Widescreen:  Yes
   Image Aspect Ratio:  16:9
   Features:  Anti-glare

Audio & Video
   Graphics Processor:  Intel HD Graphics
   Camera:  Integrated webcam
   Resolution (MP):  1 Megapixel
   Resolution:  720p
   Sound:  Stereo speakers , microphone

Input
   Type:  Keyboard, touchpad
   Features:  Spill-resistant

Communications
   Wireless:  Bluetooth 4.0, 802.11ac
   Wireless Controller:  Intel Dual Band Wireless-AC 7260 - M.2 Card

Battery
   Technology:  3-cell lithium ion
   Capacity:  45 Wh
   Run Time:  Up to 10 hours

AC Adapter 
   Input:  AC 120/230 V ( 50/60 Hz )
   Output:  45 Watt , 20 V , 2.25 A

Connections & Expansion
   Interfaces:  USB 3.0 ¦ 2 x USB 2.0 ¦ HDMI ¦ Headphone/microphone combo jack
   Memory Card Reader:  Yes ( microSD )

Miscellaneous
   Features:  Security lock slot (cable lock sold separately), administrator password, hard drive password, power-on password
   Included Accessories:  Power adapter
   Localization:  English
   Manufacturer Selling Program:  TopSeller

Dimensions & Weight
   Dimensions (WxDxH):  11.8 in x 8.5 in x 0.9 in
   Weight:  2.84 lbs

Manufacturer Warranty
   Service & Support:  1 year warranty
   Service & Support Details:  Limited warranty - 1 year - carry-in 
   <br /> <br />
   </td>
      <td> $380.00 </td>
	  
	  </tr>
      <tr>
        <th>  </th>
        <td>
		<fieldset>
  <legend> <br /> Buy <br />
						It <br /> Now</legend>

		<label> <input type = "radio"  name = "Laptop"  
                       value = "3" id = "Asus"
                        /> Free <br /> Shipping</label>
						
						</fieldset>
						</td>

		<td> ASUS EeeBook X205TA-DH01 - 11.6" - Atom Z3735</td>
        <td> <img src = "pc3.jpg"  alt = "PC3 pic" /> </td> 
        <td> 
		
		<p class = "three">	
		
		The ASUS EeeBook X205 is an affordable 11.6-inch notebook that
		weighs less than 1 kg and has a compact, space-saving design. EeeBook
		X205 allows you to surf the net for up to 12 hours on a full charge.


Specifications
General
   Product Type:  Notebook
   Operating System:  Windows 8.1

Processor / Chipset
   CPU:  Intel Atom Z3735F / 1.33 GHz
   Max Turbo Speed:  1.83 GHz
   Number of Cores:  Quad-Core
   Cache:  2 MB
   64-bit Computing:  Yes

Memory
   RAM:  2 GB ( provided memory is soldered )
   Technology:  DDR3L SDRAM
   Speed:  1333 MHz

Storage
   Main Storage:  32 GB SSD
   SSD Form Factor:  eMMC

Display
   Type:  11.6"
   LCD Backlight Technology:  LED backlight
   Resolution:  1366 x 768 ( HD )
   Widescreen:  Yes
   Image Aspect Ratio:  16:9
   Features:  ASUS Splendid Video Intelligence Technology, glare

Audio & Video
   Graphics Processor:  Intel HD Graphics
   Camera:  Integrated webcam
   Resolution:  VGA
   Sound:  Stereo speakers , microphone
   Audio Features:  ASUS SonicMaster

Input
   Type:  Keyboard, touchpad
   Features:  Multi-touch touchpad, ASUS Smart Gesture technology

Communications
   Wireless:  802.11n, Bluetooth 4.0

Battery
   Technology:  2-cell lithium polymer
   Capacity:  38 Wh
   Run Time:  Up to 13 hours
   Battery Run Time:  Audio playback - up to 13 hours ¦ Web browsing - up to 12 hours ¦ Video playback - up to 11 hours

AC Adapter
   Input:  AC 120/230 V ( 50/60 Hz )
   Output:  33 Watt , 19 V , 1.75 A

Connections & Expansion
   Interfaces:  2 x USB 2.0 ¦ Micro-HDMI ¦ Headphone/microphone combo jack
   Memory Card Reader:  Yes ( microSD, microSDHC, microSDXC )

Software
   Software Included:  500 GB ASUS WebStorage (24 months)

Miscellaneous
   Color:  Blue
   Included Accessories:  Power adapter
   Compliant Standards:  UL, C-Tick, BSMI, CB, JATE, CCC, MIC, FCC, RoHS, A-Tick, GOST-R, iDA, ErP 2013

Dimensions & Weight
   Dimensions (WxDxH):  11.3 in x 7.6 in x 0.7 in
   Weight:  34.56 oz

Environmental Standards
   ENERGY STAR Qualified:  Yes 
   
   <br /> <br />
   </td>
   
   <td> $599.00 </td>
      </tr>
      <tr>
        <th>  </th>
        <td>
		<fieldset>
  <legend> <br /> Buy <br />
						It <br /> Now</legend>

		<label> <input type = "radio"  name = "Laptop"  
                       value = "4" id = "Dell"
                        /> Free <br /> Shipping</label>
						
						</fieldset>
		
		<td> Dell Chromebook 11 3120 - 11.6" - Celeron N2840 </td>
        <td> <img src = "pc4.jpg"  alt = "PC pic" /> </td> 
        <td>
		
		
		<p class = "four">	
		Enjoy a hassle-free experience with the affordable Dell Chromebook 11 with easy connectivity, long battery life and automatic security updates.


Specifications
General
   Product Type:  Chromebook
   Operating System:  Google Chrome OS

Processor / Chipset
   CPU:  Intel Celeron N2840 / 2.16 GHz
   Max Turbo Speed:  2.58 GHz
   Number of Cores:  Dual-Core
   Cache:  L2 - 1 MB
   64-bit Computing:  Yes
   Features:  Intel Burst Technology

Memory
   RAM:  2 GB
   Max RAM Supported:  4 GB
   Technology:  DDR3L SDRAM

Storage
   Main Storage:  16 GB SSD
   SSD Form Factor:  eMMC

Display
   Type:  11.6"
   Resolution:  1366 x 768 ( HD )
   Widescreen:  Yes
   Features:  Anti-glare

Audio & Video
   Graphics Processor:  Intel HD Graphics
   Camera:  Integrated webcam
   Resolution (MP):  0.92 Megapixel
   Resolution:  1280 x 720
   Camera Features:  HD video recording
   Sound:  Speakers , two microphones
   Compliant Standards:  High Definition Audio

Input
   Type:  Keyboard, touchpad
   Keyboard Layout:  English

Communications
   Wireless:  Bluetooth 4.0, 802.11ac

Battery
   Technology:  3-cell
   Capacity:  43 Wh

AC Adapter
   Input:  AC 120/230 V ( 50/60 Hz )
   Output:  65 Watt , 19.5 V , 6.67 A

Connections & Expansion
   Interfaces:  Headphone/microphone combo jack ¦ USB 2.0 ¦ USB 3.0 ¦ HDMI
   Memory Card Reader:  Yes ( SD Card )

Miscellaneous
   Color:  Blue
   Image Color Disclaimer:  The image of the product displayed may be of a different color
   Features:  Security lock slot (cable lock sold separately), 180 degree tilted rotation
   Included Accessories:  Power adapter

Dimensions & Weight
   Width:  11.7 in
   Depth:  8.5 in
   Height:  0.8 in
   Weight:  2.8 lbs

Manufacturer Warranty
   Service & Support:  1 year warranty
   Service & Support Details:  Limited warranty - 1 year - on-site

Environmental Parameters
   Min Operating Temperature:  32 °F
   Max Operating Temperature:  104 °F
   Humidity Range Operating:  10 - 90% (non-condensing)  </td>
   
  <td> $299.99 </td>
      
	 

       

</table>

	<p> <label>
	Your Name: <br>    
	<input type= <?php print("$InputType"); ?> name = "name" id = "custName" size = "25" value = <?php print("$name"); ?> /> 
	<?php if(isset($_SESSION['posted'])) {print("$name");}?> <br> </label>
	<label> Your Age: <br>     
	<input type=  <?php print("$InputType"); ?> name = "age" id = "age" value = <?php print("$age"); ?> /> 
	<?php if(isset($_SESSION['posted'])) {print("$age");}?> <br> </label>
  
  
  
 <input type="submit" value="Order"/>
<input type = "reset"  value = "Clear Order Form"/> 


</p> 
  
  
	<a href="index.php"> HOME </a>

</form>
  
  
  </body>
</html>
