<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- PC Repair
     An example to illustrate repair shop
     -->
<html lang = "en"  xmlns = "http://www.w3.org/1999/xhtml">
  <head> 
    <title> My Repair Shop </title>
 <!--   <meta charset = "utf-8" /> -->
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  
  </head>
  <body>
    <h1> PJN PC Repair </h1>
    <h2> Locally Owned and Operated!!! Over 25 years of experience!!! </h2>
    <h3> "If you can't bring it in, we will come to you" </h3>
    <hr />
    <p>
      
      <a href = "History.php"> Our History</a>   
	  <a href = "Items.php"> Webstore</a>   
	  <a href = "antivirus.php"> Calculate Spyware</a> 
	  <a href = "statstable.php">Rates</a>    
	  <a href = "evilgame.php">Evil Game</a>
	  <a href = "statstable2.php">RatesPHP</a> 
    </p>
    <p>
      <br />
      <img src = "pcrepair.png"  alt = "PC Repair pic" />
      <br />
      GET A FREE QUOTE OR CALL TODAY!!!
      <br />
      Our techs are available 24/7!!! 
	  <br />
	  800-888-8888  Call now!!!
    </p>
  </body>
</html>
