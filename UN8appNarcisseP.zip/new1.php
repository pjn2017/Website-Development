<?php echo '<xml version = "1.0" encoding = "IUTF-8"?>';?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtmlll/DTD/xhtmll-strict.dtd">
<html xmlns = "http://www.w3.org/1999/xhtml">
<!-- showHide.html
Uses showHide.js
Illustrates visibility control of elements
-->
<html xmlns = "http://www.w3.org/1999/xhtml">
<head>
<title> Visibility control </title>
<script type = "text/javascript" src = "evilgame.js" >
</script>
</head>
<body >
<form action = "">
<p> Try to click the image </p> <br />
<div id = "amps" style = "position: relative; visibility: visible;" onmousedown = "moveImage()">
<img src = "tech.jpg" alt = "amp" />
</div>
</form>
</body>
</html>