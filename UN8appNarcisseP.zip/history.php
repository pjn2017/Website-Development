<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr" xml:lang="fr">


<!-- History.html
     An example to illustrate history of company
     -->

  <head> 
    <title> History </title>
    
   <link rel = "stylesheet"  type = "text/css"
          href = "style.css" />
  
  </head>
  <body>
  <h1> Our Core Values </h1>
    <ol>
      <li> Always Innovating</li>
      <li> Never Stop Learning </li>
      <li> Always Thriving to Make it Better </li>
      <li> Dedicated and Responsible </li>
      <li> 100% Guaranteed Results</li>
    </ol>
    <hr />
    
      HISTORY
	   <br />
	   <br />
	  Who We Are
	  <br />
	   <br />
	   <p>
We at PJN Repair are obsessed about find solutions to problems.
We’re waiting for the latest technology to hit the market. We 
love all things tech, but we have a passion for helping other. 
We don't consider ourselves geniuses, but we are experts at what we do.
</p>
<blockquote>

<br />
 <br />
What We Do
<br />
 <br />
 <p>
PJN Repair fixes electronic devices. For whatever reason you damage your device,
 we are equipped to resolve your issues. Don’t worry, we’ve been there ourselves,
 we understand how devastating it is when you break your precious devices.
</p>

<br />
 <br />
Why We Do It
<br />
 <br />
<p>
 We do because we care about people and their tech. 
 That’s why PJN Repair works; we put our customers above anything else. 
 Of course we love fixing cracked iPhone screens and broken charge ports,
 but we get our satisfaction from helping out folks who lost their connection to the outside world.
</p>
</blockquote>
    
   <p>
    <a href="index.php"> HOME </a>
</p>
      
  </body>
</html>
